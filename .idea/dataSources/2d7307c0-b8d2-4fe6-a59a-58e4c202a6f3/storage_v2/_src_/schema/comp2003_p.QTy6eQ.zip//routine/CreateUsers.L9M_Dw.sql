create
    definer = COMP2003_P@`%` procedure CreateUsers(IN p_Username varchar(25), IN p_Password varchar(25),
                                                   IN p_Email varchar(255))
BEGIN
INSERT INTO registeredusers(Username, UPasswords, Email) VALUES (p_Username, p_Password, p_Email);
END;

