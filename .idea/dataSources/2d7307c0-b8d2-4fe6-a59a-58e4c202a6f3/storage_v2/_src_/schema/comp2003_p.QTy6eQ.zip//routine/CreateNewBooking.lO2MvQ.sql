create
    definer = COMP2003_P@`%` procedure CreateNewBooking(IN FirstName varchar(25), IN LastName varchar(25),
                                                        IN p_Booking_StartDate date, IN p_Booking_EndDate text,
                                                        IN p_Gender varchar(6), IN p_Age int, IN p_AmountOfPeople int,
                                                        IN p_PreferredRoom varchar(11), IN p_Price decimal)
BEGIN
INSERT INTO hostelbookings(First_Name, Last_Name, Booking_StartDate, Booking_EndDate, Gender, Age, AmountOfPeople, Preferred_Room, Price) 
VALUES (FirstName, LastName, p_Booking_StartDate, p_Booking_EndDate, p_Gender, p_Age, p_AmountOfPeople, p_PreferredRoom, p_Price);
END;

