create
    definer = COMP2003_P@`%` procedure CreateAdminUsers(IN p_Username varchar(25), IN p_Password varchar(25),
                                                        IN p_LoginNum int)
BEGIN
INSERT INTO registeredadmins(Username, UPasswords, LoginNum) VALUES (p_Username, p_Password, p_LoginNum);
END;

